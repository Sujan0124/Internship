package Page;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Samsung_Mobiles {
	WebDriver dr;
	
    
    public Samsung_Mobiles(WebDriver dr) {
        this.dr = dr;
        PageFactory.initElements(dr, this);
    }

    @FindBy(xpath = "/html/body/div[1]/div[1]/div[2]/div[3]/div/div/div/div[4]/div[9]/span/div/div/div[1]/span/a/div/img")
    WebElement select_mobile_33;

    @FindBy(xpath = "//div/h1/span[@id=\"productTitle\"]")
    WebElement Mobile_name;

    @FindBy(xpath = "//span[@class=\"a-price aok-align-center reinventPricePriceToPayMargin priceToPay\"]/span/span[@class=\"a-price-whole\"]")
    WebElement Mobile_price;

    @FindBy(xpath = "//div[@class=\"a-section a-spacing-small a-spacing-top-small\"]")
    WebElement Mobile_specifications;

    String MobileName;

    

    public void select_3mobile() throws InterruptedException {
    	JavascriptExecutor js = (JavascriptExecutor) dr;
        js.executeScript("window.scrollBy(0,1500)");
        Thread.sleep(5000); 
        select_mobile_33.click(); 
    }

    public void mobile_name() throws InterruptedException {
        Thread.sleep(5000); // Use WebDriverWait for better synchronization
        MobileName = Mobile_name.getText();
        MobileName = MobileName.split("\\(")[0].trim();
        System.out.println("Name of the Mobile you have selected is: " + MobileName);
    }

    public void mobile_price() {
    	//js.executeScript("window.scrollBy(0,500)");
        String priceText = Mobile_price.getText();
        priceText = priceText.replace(",", "").trim();
        int Mobile_price = Integer.parseInt(priceText);
        System.out.println("Price of the Mobile you have selected is: ₹" + Mobile_price);
    }

    public void mobile_specifications() {
        String specifications = Mobile_specifications.getText();
        System.out.println("Specifications of " + MobileName + " are \n" + specifications);
    }
}