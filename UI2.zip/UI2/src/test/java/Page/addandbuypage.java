package Page;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class addandbuypage {
	WebDriver dr;
    public addandbuypage(WebDriver dr) {
        this.dr = dr;
        PageFactory.initElements(dr, this);
    }

    @FindBy(xpath = "div[@id='desktop_qualifiedBuyBox']/div/div[@id='addToCart_feature_div'][2]/div/span/span")
    WebElement addToCart;

    @FindBy(xpath = "//span[@id='submit.buy-now-announce']")
    WebElement buyNow;

    public void verifyButtonPresence(String buttonXpath, String buttonName) {
        List<WebElement> buttons = dr.findElements(By.xpath(buttonXpath));
        if (buttons.size() > 0) {
            System.out.println(buttonName + " button is Present!");
        } else {
            System.out.println(buttonName + " button is NOT Present!");
        }
    }

    public void verifyAddToCartButton() {
        verifyButtonPresence("div[@id='desktop_qualifiedBuyBox']/div/div[@id='addToCart_feature_div'][2]/div/span/span", "Add to Cart");
    }

    public void verifyBuyNowButton() {
        verifyButtonPresence("//span[@id='submit.buy-now-announce']", "Buy Now");
    }
}