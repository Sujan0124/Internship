package StepDef;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import Page.Amazon;
import Page.samsungwatchpage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import utilities.loggerUtil;

public class samsungwatchstepdef{
  samsungwatchpage swp;
  
  WebDriver dr = Amazon.dr;
  
  @Given("I am on the Amazon Product page")
  public void i_am_on_the_amazon_homepage() {
	  try {
      System.out.println("Product Page is Displayed successfully");
     
  }catch(Exception e) {
		String errorMessage = "Test failed: " + e.getMessage();
		loggerUtil.logFailure(errorMessage, e);
		loggerUtil.takeScreenshot(dr);
		throw e;
  		}
	}
  @When("I enter Samsung watch in the search bar")
  public void i_enter_samsung_watch_in_the_search_bar() {
	  try {
	  swp = new samsungwatchpage(dr);
      swp.srchbox();
	  }catch(Exception e) {
			String errorMessage = "Test failed: " + e.getMessage();
			loggerUtil.logFailure(errorMessage, e);
			loggerUtil.takeScreenshot(dr);
			throw e;
	  		}
    
  }
  @Then("I click the search button")
  public void i_click_the_search_button() {
	  try {
	  swp = new samsungwatchpage(dr);
	  swp.srch();
	 
  }catch(Exception e) {
		String errorMessage = "Test failed: " + e.getMessage();
		loggerUtil.logFailure(errorMessage, e);
		loggerUtil.takeScreenshot(dr);
		throw e;
	}}
  @When("I should see a list of search results")
  public void i_should_see_a_list_of_search_results() {
	  try {
      System.out.println("Results of Samsung Watches appeared");
      JavascriptExecutor js = (JavascriptExecutor)dr;
      js.executeScript("window.scrollBy(0,500)");
  }catch(Exception e) {
		String errorMessage = "Test failed: " + e.getMessage();
		loggerUtil.logFailure(errorMessage, e);
		loggerUtil.takeScreenshot(dr);
		throw e;
	}}
  
  @Then("I select a random product from the results")
  public void i_select_a_random_product_from_the_results() {
	  try {
	  swp = new samsungwatchpage(dr);
	  swp.txt();
	  }
	  catch(Exception e) {
			String errorMessage = "Test failed: " + e.getMessage();
			loggerUtil.logFailure(errorMessage, e);
			loggerUtil.takeScreenshot(dr);
			throw e;
	  		}
	  
  }
  @Then("the product title should contain the word Samsung")
  public void the_product_title_should_contain_the_word_samsung() {
	  try {
	  swp = new samsungwatchpage(dr);
	  swp.price();
	 
  }catch(Exception e) {
		String errorMessage = "Test failed: " + e.getMessage();
		loggerUtil.logFailure(errorMessage, e);
		loggerUtil.takeScreenshot(dr);
		throw e;
	}}
}
