package StepDef;

import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import utilities.loggerUtil;

public class Hook{
	@Before

	 public void beforeScenario(Scenario scenario) {
		System.out.println("Starting scenario: " + scenario.getName());
		
		}


	@After
	public void afterScenario(Scenario scenario) {
		if (scenario.isFailed()) {
			String errorMessage = "Scenario failed: " + scenario.getName();
			Throwable throwable = new Throwable(errorMessage);
			loggerUtil.logFailure(errorMessage, throwable);
 
			}
		}
 

}

