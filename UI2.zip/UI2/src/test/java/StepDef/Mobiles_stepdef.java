package StepDef;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

import com.aventstack.extentreports.Status;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import utilities.loggerUtil;
import Page.Samsung_Mobiles;

public class Mobiles_stepdef{
    Samsung_Mobiles sm;
    
    WebDriver dr = AmazonStepDef.dr;

    @Given("I navigate to mobiles website under Samsung category")
    public void samsung_mobiles_listed_page() {
        try {
        sm = new Samsung_Mobiles(dr); // Initialize Page Object with WebDriver
        //dr.get("https://www.amazon.in/s/ref=mega_elec_s23_1_2_1_4?rh=i%3Aelectronics%2Cn%3A4363159031&ie=UTF8&bbn=976419031");
        System.out.println("Samsung mobiles are displayed");
        //test = extent.createTest("Navigate to Samsung Mobiles");

    }catch(Exception e) {
		String errorMessage = "Test failed: " + e.getMessage();
		loggerUtil.logFailure(errorMessage, e);
		loggerUtil.takeScreenshot(dr);
		throw e;
	}}

    @When("I select the 3rd row 3rd mobile under the samsung category")
    public void selecting_3rd_row_third_mobile() throws InterruptedException {
    	try {
    	sm = new Samsung_Mobiles(dr);
        sm.select_3mobile(); 
       
    }catch(Exception e) {
		String errorMessage = "Test failed: " + e.getMessage();
		loggerUtil.logFailure(errorMessage, e);
		loggerUtil.takeScreenshot(dr);
		throw e;
	}}

    @Then("capture the name and price of the selected mobile")
    public void capture_name_and_price() throws InterruptedException {
    	try {
    	sm = new Samsung_Mobiles(dr);
        sm.mobile_name();
        sm.mobile_price();
       
    }catch(Exception e) {
		String errorMessage = "Test failed: " + e.getMessage();
		loggerUtil.logFailure(errorMessage, e);
		loggerUtil.takeScreenshot(dr);
		throw e;
	}}

    @And("I also capture the specifications of the selected mobile")
    public void capture_specifications() {
    	try {
    	sm = new Samsung_Mobiles(dr);
        sm.mobile_specifications();
        
    }catch(Exception e) {
		String errorMessage = "Test failed: " + e.getMessage();
		loggerUtil.logFailure(errorMessage, e);
		loggerUtil.takeScreenshot(dr);
		throw e;
	}}
}