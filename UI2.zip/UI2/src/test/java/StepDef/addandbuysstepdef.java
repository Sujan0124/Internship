package StepDef;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;

import Page.addandbuypage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import utilities.loggerUtil;
import utilities.loggerUtil;

public class addandbuysstepdef{
	WebDriver dr = AmazonStepDef.dr;
	addandbuypage aabp;
	
	@Given("I am on the product page")
	public void i_am_on_the_product_page() {
		try {
	    System.out.println("In the Product page");
	   
		}catch(Exception e) {
    		String errorMessage = "Test failed: " + e.getMessage();
    		loggerUtil.logFailure(errorMessage, e);
    		loggerUtil.takeScreenshot(dr);
    		throw e;
    	}
	}
	@When("the page is fully loaded")
	public void the_page_is_fully_loaded() {
	  try { 
		System.out.println("Page is loaded Successfully");
		
	  }catch(Exception e) {
  		String errorMessage = "Test failed: " + e.getMessage();
  		loggerUtil.logFailure(errorMessage, e);
  		loggerUtil.takeScreenshot(dr);
  		throw e;
  	}
	}
	@Then("I should see the Add to Cart and Buy Now buttons")
	public void i_should_see_the_add_to_cart_and_buy_now_buttons() {
		
		try{aabp = new addandbuypage(dr);
		aabp.verifyAddToCartButton();
		aabp.verifyBuyNowButton();
		
		}catch(Exception e) {
    		String errorMessage = "Test failed: " + e.getMessage();
    		loggerUtil.logFailure(errorMessage, e);
    		loggerUtil.takeScreenshot(dr);
    		throw e;
    	}
	}
	
}
