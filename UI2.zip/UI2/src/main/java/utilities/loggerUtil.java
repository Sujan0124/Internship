package utilities;
 
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
//import java.util.logging.FileHandler;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.io.FileHandler;
 
public class loggerUtil {
	private static final String LOG_FILE = "C:\\Users\\mynam.sujan\\eclipse-workspace\\UI\\target\\logfile.txt";
	public static void logFailure(String message, Throwable throwable) {
		try (BufferedWriter writer = new BufferedWriter(new FileWriter(LOG_FILE, true))) {
			writer.write(message);
			writer.newLine();
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			throwable.printStackTrace(pw);
			writer.write(sw.toString());
			writer.newLine();}
		catch (IOException e) {
			e.printStackTrace();
			}
		}
	public static String takeScreenshot(WebDriver driver) {
    	WebDriver driver1= driver;
        String timestamp = new java.text.SimpleDateFormat("yyyy-MM-dd_HH-mm-ss").format(new java.util.Date());
        String screenshotPath = "C:\\Users\\mynam.sujan\\eclipse-workspace\\UI2\\target\\screenshot " + timestamp + ".png";
        File screenshot = ((TakesScreenshot) driver1).getScreenshotAs(OutputType.FILE);
        try {
        	FileHandler.copy(screenshot, new File(screenshotPath));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return screenshotPath;
    }

 
}