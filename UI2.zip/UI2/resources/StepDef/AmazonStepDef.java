package StepDef;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

import Page.Amazon;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;

public class AmazonStepDef {
    WebDriver driver;
    Amazon amazon;

    @Given("Microsoft Edge is open")
    public void microsoft_edge_is_open() {
        System.setProperty("webdriver.edge.driver", "C:\\Users\\mynam.sujan\\eclipse-workspace\\UI\\msedgedriver_V_135.exe");
        driver = new EdgeDriver();
        amazon = new Amazon(driver);
        driver.manage().window().maximize();
    }

    @When("the user searches for Amazon in the search bar")
    public void the_user_navigates_to_the_amazon_website() {
        driver.get("https://www.amazon.com");
    }

    @Then("the user navigates to the Amazon website")
    public void the_user_clicks_on_the_category(String string) {
        amazon.CLICK();
    }

    @When("the user clicks on the Mobiles category and the user hovers over \"Mobiles & Accessories")
    public void the_user_hovers_over(String string) throws InterruptedException {
        amazon.hoverOnCategory();
    }

    @Then("the user selects Samsung Mobiles")
    public void the_user_selects(String string) {
        amazon.samclick();
    }
}