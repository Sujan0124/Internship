package utilities;
 
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
 
 
public class loggerUtil {
	private static final String LOG_FILE = "C:\\Users\\mynam.sujan\\eclipse-workspace\\UI\\target\\logfile.txt";
	public static void logFailure(String message, Throwable throwable) {
		try (BufferedWriter writer = new BufferedWriter(new FileWriter(LOG_FILE, true))) {
			writer.write(message);
			writer.newLine();
			StringWriter sw = new StringWriter();
			PrintWriter pw = new PrintWriter(sw);
			throwable.printStackTrace(pw);
			writer.write(sw.toString());
			writer.newLine();}
		catch (IOException e) {
			e.printStackTrace();
			}
		}
 
 
}