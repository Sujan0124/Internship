package StepDef;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

import com.aventstack.extentreports.Status;

import Base.baseTest;
import Page.Amazon;
import Page.Samsung_Mobiles;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import utilities.loggerUtil;
import io.cucumber.java.en.Then;

public class AmazonStepDef extends baseTest {
    static WebDriver dr;
    Amazon amazon;
    Samsung_Mobiles sm;
    

    @Given("Microsoft Edge is open")
    
    public void microsoft_edge_is_open() {
    	try {
        // Initialize the EdgeDriver and Amazon page object
        System.setProperty("webdriver.edge.driver", "C:\\Users\\mynam.sujan\\eclipse-workspace\\UI\\msedgedriver_V_135.exe");
        dr = new EdgeDriver();
        amazon = new Amazon(dr);
        dr.manage().window().maximize();
        sm=new Samsung_Mobiles(dr);
    }catch(Exception e) {
		String errorMessage = "Test failed: " + e.getMessage();
		loggerUtil.logFailure(errorMessage, e);
		throw e;
	}
    }
    @When("the user searches for Amazon in the search bar")
    public void the_user_searches_for_amazon_in_the_search_bar() {
    	try {
        // Navigate to the Amazon website
        dr.get("https://www.amazon.in");
       
    }catch(Exception e) {
		String errorMessage = "Test failed: " + e.getMessage();
		loggerUtil.logFailure(errorMessage, e);
		throw e;
	}}

    @Then("the user navigates to the Amazon website")
    public void the_user_navigates_to_the_amazon_website() {
        // Perform navigation or validation action
        amazon.CLICK();
        
    }

    @When("the user clicks on the Mobiles category and the user hovers over Mobiles & Accessories")
    public void the_user_clicks_and_hovers_on_mobiles_category() throws InterruptedException {
        // Hover over the specified element
    	try {
        amazon.hoverOnCategory();
        
    }catch(Exception e) {
		String errorMessage = "Test failed: " + e.getMessage();
		loggerUtil.logFailure(errorMessage, e);
		throw e;
	}}

    @Then("the user selects Samsung Mobiles")
    public void the_user_selects_samsung_mobiles() {
        // Click on the Samsung option
    	try {
        amazon.samclick();
    }catch(Exception e) {
		String errorMessage = "Test failed: " + e.getMessage();
		loggerUtil.logFailure(errorMessage, e);
		throw e;
	}}
    
    
    
    
    
}