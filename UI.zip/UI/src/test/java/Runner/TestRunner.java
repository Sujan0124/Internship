package Runner;



import io.cucumber.testng.CucumberOptions;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import Base.baseTest;
import io.cucumber.testng.AbstractTestNGCucumberTests;

@CucumberOptions(
	    features = {"src/test/java/Feature"},
	    glue = {"StepDef"},
	    plugin = {"pretty", "html:target/cucumber-reports.html","com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"}
	    //tags ="@set1"
		)

public class TestRunner extends AbstractTestNGCucumberTests {

}

