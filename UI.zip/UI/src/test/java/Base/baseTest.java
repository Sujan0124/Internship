package Base;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class baseTest {
	public static ExtentReports extent;
	public static ExtentTest test;
	public static void setUpExtentReport() {
		ExtentSparkReporter sparkReporter = new ExtentSparkReporter("target/extentreports/extent-report.html");
		sparkReporter.config().setTheme(Theme.STANDARD);
		sparkReporter.config().setDocumentTitle("Test Report");
		sparkReporter.config().setReportName("Amazon Project Report");
		extent = new ExtentReports();
		extent.attachReporter(sparkReporter);

		}
	public static void tearDownExtentReport() {
		extent.flush();
		}
}
