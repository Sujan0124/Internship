package Page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class samsungwatchpage {
	
	WebDriver dr;
    public samsungwatchpage(WebDriver dr) {
        this.dr = dr;
        PageFactory.initElements(dr, this);
    }
    
    @FindBy(xpath = "//div[@class=\"nav-search-field \"]/input[@id=\"twotabsearchtextbox\"]")
    WebElement searchbox;
    @FindBy(xpath = "//div[@class=\"nav-search-submit nav-sprite\"]/span[@id=\"nav-search-submit-text\"]")
    WebElement search;
    @FindBy(xpath = "//div[6]//div[@class=\"a-section a-spacing-small puis-padding-left-small puis-padding-right-small\"]/div[@data-cy=\"title-recipe\"]/a")
    WebElement text;
    @FindBy(xpath = "//div[6]//div[@class=\"a-section a-spacing-small puis-padding-left-small puis-padding-right-small\"]//span[@class=\"a-price-whole\"]")
    WebElement price;
    public void srchbox() {
		searchbox.sendKeys("Samsung Watches");
	}
    public void srch() {
    	search.click();
	}
    public void txt() {
		String name = text.getText();
		if(name.contains("Samsung")) {
            System.out.println("Samsung is present");
        } else {
            System.out.println("Samsung is NOT present");
        }
		
	}
    public void price() {
    	String priceText = price.getText();
		priceText = priceText.replace(",", "").trim();
        int Watch_Price = Integer.parseInt(priceText);
        System.out.println("Price of the Watch you have selected is: ₹" + Watch_Price);

	}

}
