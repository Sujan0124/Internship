package Page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Amazon {
	public static WebDriver dr;
@FindBy(xpath="//div[@id='nav-xshop']/ul/li[6]/div/a")
WebElement click;

@FindBy(xpath="//*[@id=\"nav-subnaV\"]/a[2]/span[1]")
WebElement hover;

@FindBy(xpath="//*[@id=\"nav-flyout-aj:https://images-eu.ssl-images-amazon.com/images/G/31/img18/Electronics/Megamenu/megamenumar18f.json:subnav-sl-megamenu-1:0\"]/div[2]/div/div[2]/ul/li[3]/a")
WebElement samsung;




 public Amazon(WebDriver dr) {
	 this.dr=dr;
	 PageFactory.initElements(dr,this);
 }
public void CLICK() {
	click.click();
}
public void hoverOnCategory() throws InterruptedException {
    Actions action = new Actions(dr);
    action.moveToElement(hover).perform();
    Thread.sleep(3000);
}
public void samclick() {
	samsung.click();
}

}
