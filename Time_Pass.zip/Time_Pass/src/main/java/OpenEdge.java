import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class OpenEdge {
    public static void main(String[] args) throws InterruptedException {
        System.setProperty("webdr.edge.dr", "C:\\Users\\mynam.sujan\\eclipse-workspace\\Time_Pass\\msedgedr_V_135.exe");

        WebDriver dr = new EdgeDriver();
        dr.manage().window().maximize();
        dr.get("https://www.google.com");
        WebDriverWait wait = new WebDriverWait(dr, Duration.ofSeconds(10));
        WebDriverWait wait2 = new WebDriverWait(dr, Duration.ofSeconds(5));

        WebElement textarea = wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@jscontroller=\"vZr2rb\"]//textarea")));
        textarea.sendKeys("S");

        WebElement button = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id=\"jZ2SBf\"]/div[1]/span/b")));
        button.click();
        WebElement Captcha = wait2.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class=\"recaptcha-checkbox-border\"]")));
        Captcha.click();
        //dr.quit();
    }
}