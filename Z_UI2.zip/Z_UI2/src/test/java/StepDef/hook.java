package StepDef;


import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import utilities.loggerUtil;

public class hook {

    @Before
    public void beforeScenario(Scenario scenario) {
    	
    }

    @After
    public void afterScenario(Scenario scenario) {
        if (scenario.isFailed()) {
            String errorMessage = "Scenario failed: " + scenario.getName();
            Throwable throwable = new Throwable(errorMessage);
            loggerUtil.logFailure(errorMessage, throwable);
        }
    }
}