package StepDef;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import Page.amazon;
import Page.samsungMobiles;
import utilities.ExcelUtil;
import utilities.loggerUtil;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
public class amazonStepDef{
    static WebDriver dr;
    amazon amazon;
    samsungMobiles sm;
    @Given("The browser launches the home page of amazon") 
    public void The_browser_launches_the_home_page_of_amazon() throws Exception {
    	try {
    		
    		 loggerUtil.clearLogFile();
    	      System.setProperty("webdriver.edge.driver", "C:\\Users\\mynam.sujan\\eclipse-workspace\\Z_UI\\msedgedriver_V_135.exe");
    	      ExcelUtil.setExcelFile("C:\\Users\\mynam.sujan\\Desktop\\XPATH_DATA.xlsx", "Sheet1");
    	      dr = new EdgeDriver();
    	      dr.get(ExcelUtil.getTestData("url"));
    	      dr.manage().window().maximize();
    	      amazon = new amazon(dr);
    	}catch(Exception e) {
    		String errorMessage = "Test failed: " + e.getMessage();
    		loggerUtil.logFailure(errorMessage, e);
    		loggerUtil.takeScreenshot(dr);
    		throw e;
    	}
    }
    @When("the user clicks on the Mobiles category and the user hovers over Mobiles & Accessories")
    public void the_user_clicks_and_hovers_on_mobiles_category() throws InterruptedException {
    	try {
    		amazon.CLICK();
            amazon.hoverOnCategory();
    	}catch(Exception e){
    		String errorMessage = "Test failed: " + e.getMessage();
    		loggerUtil.logFailure(errorMessage, e);
    		loggerUtil.takeScreenshot(dr);
    		throw e;
    	}
    }
    @Then("the user selects Samsung Mobiles")
    public void the_user_selects_samsung_mobiles() {
    	try {
            amazon.samclick();
    	}catch(Exception e) {
    		String errorMessage = "Test failed: " + e.getMessage();
    		loggerUtil.logFailure(errorMessage, e);
    		loggerUtil.takeScreenshot(dr);
    		throw e;
    	}
    }
}