package StepDef;

import org.openqa.selenium.WebDriver;
import Page.amazon;
import Page.samsungWatchPage;
import utilities.loggerUtil;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
public class samsungWatchStepDef{
    samsungWatchPage swp;
    WebDriver dr = amazon.dr;
    @When("I enter Samsung watch in the search bar")
    public void i_enter_samsung_watch_in_the_search_bar() {
        try {
            swp = new samsungWatchPage(dr);
            swp.srchbox();
        }catch(Exception e){
            String errorMessage = "Test failed: " + e.getMessage();
            loggerUtil.logFailure(errorMessage, e);
            loggerUtil.takeScreenshot(dr);
            throw e;
        }
    }
    @Then("I click the search button")
    public void i_click_the_search_button() {
        try {
            swp = new samsungWatchPage(dr);
            swp.srch();
        }catch(Exception e){
            String errorMessage = "Test failed: " + e.getMessage();
            loggerUtil.logFailure(errorMessage, e);
            loggerUtil.takeScreenshot(dr);
            throw e;
        }
    }
    @Then("retrieve name an price of a random watch from the results and check if it contains the word samsung")
    public void retrieve_name_an_price_of_a_random_watch_from_the_results_and_chechk_if_it_contains_the_word_Samsung() {
        try {
            swp = new samsungWatchPage(dr);
            swp.txt(); 
            swp.price();
        } catch (AssertionError e) { 
            String errorMessage = "Test failed: " + e.getMessage();
            loggerUtil.logFailure(errorMessage, e);
            loggerUtil.takeScreenshot(dr);
            throw e; 
        }
    }
}