package StepDef;
import org.openqa.selenium.WebDriver;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import Page.samsungMobiles;
import utilities.loggerUtil;
public class mobilesStepDef{
    samsungMobiles sm;
    WebDriver dr = amazonStepDef.dr;
    @When("I select the 3rd row 3rd mobile under the samsung category")
    public void selecting_3rd_row_third_mobile() throws InterruptedException {
    	try {
    		sm = new samsungMobiles(dr);
            sm.select_33mobile();
    	}catch(Exception e){
    		String errorMessage = "Test failed: " + e.getMessage();
    		loggerUtil.logFailure(errorMessage, e);
    		loggerUtil.takeScreenshot(dr);
    		throw e;
    	}
    }
    @Then("capture the name and price of the selected mobile")
    public void capture_name_and_price() throws InterruptedException {
    	try {
    		sm = new samsungMobiles(dr);
            sm.mobile_name();
            sm.mobile_price();
    	}catch(Exception e){
    		String errorMessage = "Test failed: " + e.getMessage();
    		loggerUtil.logFailure(errorMessage, e);
    		loggerUtil.takeScreenshot(dr);
    		throw e;
    	}
    }
    @And("I also capture the specifications of the selected mobile")
    public void capture_specifications() {
    	try {
    		sm = new samsungMobiles(dr);
            sm.mobile_specifications();
    	}catch(Exception e){
    		String errorMessage = "Test failed: " + e.getMessage();
    		loggerUtil.logFailure(errorMessage, e);
    		loggerUtil.takeScreenshot(dr);
    		throw e;
    	}
    }
}