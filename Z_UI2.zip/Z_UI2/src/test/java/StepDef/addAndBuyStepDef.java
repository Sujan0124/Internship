package StepDef;

import org.openqa.selenium.WebDriver;
import Page.addAndBuyPage;
import utilities.loggerUtil;
import io.cucumber.java.en.Then;
public class addAndBuyStepDef{

	WebDriver dr = amazonStepDef.dr;
	addAndBuyPage aabp;
	@Then("I should see the Add to Cart and Buy Now buttons")
	public void i_should_see_the_add_to_cart_and_buy_now_buttons() {
		try {
			aabp = new addAndBuyPage(dr);
			aabp.verifyAddToCartButton();
			aabp.verifyBuyNowButton();

		}catch(Exception e){
    		String errorMessage = "Test failed: " + e.getMessage();
    		loggerUtil.logFailure(errorMessage, e);
    		loggerUtil.takeScreenshot(dr);
    		throw e;
    	}
	}
}
 