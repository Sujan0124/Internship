package Page;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utilities.ExcelUtil;
public class amazon {
	public static WebDriver dr;
	public static WebElement mobiles;
	public static WebElement mobilesandaccessories;
	public static WebElement samsung;
	
	
	@SuppressWarnings("static-access")
	public amazon(WebDriver dr) {
		 this.dr=dr;
		 PageFactory.initElements(dr,this);
	}

	public void CLICK() {
		String mobilesXpath = ExcelUtil.getTestData("mobiles");
		mobiles = dr.findElement(By.xpath(mobilesXpath));
		mobiles.click();
	}
	public void hoverOnCategory() {
	    WebDriverWait wait = new WebDriverWait(dr, Duration.ofSeconds(10));
	    Actions action = new Actions(dr);
	    String mobilesandaccessoriesXpath = ExcelUtil.getTestData("mobilesandaccessories");

	    mobilesandaccessories = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(mobilesandaccessoriesXpath))); // Wait for element to be visible
	    action.moveToElement(mobilesandaccessories).perform();
	}

	public void samclick() {
	    String samsungXpath = ExcelUtil.getTestData("samsung");
	    WebDriverWait wait = new WebDriverWait(dr, Duration.ofSeconds(10)); 
	    samsung = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(samsungXpath)));
	    samsung.click();
	}

} 
 