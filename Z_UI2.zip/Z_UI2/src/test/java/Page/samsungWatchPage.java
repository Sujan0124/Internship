package Page;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utilities.ExcelUtil;

public class samsungWatchPage {
	
	WebDriver dr;
	
	public static WebElement searchbox;
	public static WebElement search;
	public static WebElement wtext;
	public static WebElement wprice;
	public static String keys;
    public samsungWatchPage(WebDriver dr) {
        this.dr = dr;
        PageFactory.initElements(dr, this); 
    }
    public void srchbox() {
    	String keys=ExcelUtil.getTestData("keys");
    	String searchboxXpath = ExcelUtil.getTestData("searchbox");
        searchbox = dr.findElement(By.xpath(searchboxXpath));
		searchbox.sendKeys(keys);
	}
    public void srch() {
       	String searchXpath = ExcelUtil.getTestData("search");
        search = dr.findElement(By.xpath(searchXpath));
    	search.click();
	}
    public void txt() {
        JavascriptExecutor js = (JavascriptExecutor) dr;
        js.executeScript("window.scrollBy(0,500);"); 

        WebDriverWait wait = new WebDriverWait(dr, Duration.ofSeconds(10));
        String wtextXpath = ExcelUtil.getTestData("wtext");
        wtext = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(wtextXpath)));

        String name = wtext.getText().trim();
        System.out.println("Extracted Text: " + name); // Debugging step

        if (name != null && !name.isEmpty() && name.contains("Samsung")) {
            System.out.println("Samsung is present");
        } else {
            System.out.println("Samsung is NOT present");
            throw new AssertionError("Test failed: 'Samsung' was not found in the extracted text!");
        }
    }
    public void price() {
       	String wpriceXpath = ExcelUtil.getTestData("wprice");
        wprice = dr.findElement(By.xpath(wpriceXpath));
    	String priceText = wprice.getText();
		priceText = priceText.replace(",", "").trim();
        int Watch_Price = Integer.parseInt(priceText);
        System.out.println("Price of the Watch you have selected is: ₹" + Watch_Price);
	}
}
