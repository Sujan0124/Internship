package Page;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver; 
import org.openqa.selenium.WebElement; 
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utilities.ExcelUtil;
public class samsungMobiles {
	WebDriver dr;
 
    public samsungMobiles(WebDriver dr) {
         this.dr = dr;
        PageFactory.initElements(dr, this); 
    }
 
    String MobileName;
    public static WebElement select_mobile_33;
    public static WebElement mname;
    public static WebElement mprice;
    public static WebElement mspecifications;
    
    public void select_33mobile() throws InterruptedException { 
    	JavascriptExecutor js = (JavascriptExecutor) dr;
        js.executeScript("window.scrollBy(0,1500)"); 
        String select_mobile_33Xpath = ExcelUtil.getTestData("select_mobile_33");
        select_mobile_33 = dr.findElement(By.xpath(select_mobile_33Xpath)); 
       select_mobile_33.click();
     }
    public void mobile_name() {
        WebDriverWait wait = new WebDriverWait(dr, Duration.ofSeconds(5)); 
        String mnameXpath = ExcelUtil.getTestData("mname");
        mname = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(mnameXpath))); 
        MobileName = mname.getText();
        MobileName = MobileName.split("\\(")[0].trim();
        System.out.println("Name of the Mobile you have selected is: " + MobileName);
    }

   public void mobile_price() {
	   JavascriptExecutor js = (JavascriptExecutor) dr;
       js.executeScript("window.scrollBy(0,500)"); 
    	String mpriceXpath = ExcelUtil.getTestData("mprice");
        mprice = dr.findElement(By.xpath(mpriceXpath));
        String priceText = mprice.getText(); 
        priceText = priceText.replace(",", "").trim();
         int Mobile_price = Integer.parseInt(priceText);

        System.out.println("Price of the Mobile you have selected is: ₹" + Mobile_price); 
    }
    public void mobile_specifications() {
    	String mspecificationsXpath = ExcelUtil.getTestData("mspecifications");
        mspecifications = dr.findElement(By.xpath(mspecificationsXpath));
        String specifications = mspecifications.getText(); 
       System.out.println("Specifications of " + MobileName + " are \n" + specifications);

    } 
}

 