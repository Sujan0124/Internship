package Page;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import utilities.ExcelUtil;

public class addAndBuyPage {
 
	WebDriver dr;
	public static WebElement addToCart;
	public static WebElement buyNow;
    public addAndBuyPage(WebDriver dr) {
        this.dr = dr;
        PageFactory.initElements(dr, this); 
    }

    public void verifyButtonPresence(String buttonXpath, String buttonName) { 
        List<WebElement> buttons = dr.findElements(By.xpath(buttonXpath));
        if (buttons.size() > 0) {
            System.out.println(buttonName + " button is Present!");
        } else {
            System.out.println(buttonName + " button is NOT Present!");
        }
    }

    public void verifyAddToCartButton() {
    	String addToCartXpath = ExcelUtil.getTestData("addToCart");
        verifyButtonPresence(addToCartXpath, "Add to Cart");
    }

    public void verifyBuyNowButton() {
    	String buyNowXpath = ExcelUtil.getTestData("buyNow");
        verifyButtonPresence(buyNowXpath, "Buy Now");
    }
 
}

 