package Runner;


import io.cucumber.testng.CucumberOptions;
import io.cucumber.testng.AbstractTestNGCucumberTests;
@CucumberOptions(
	    features = {"src/test/resources/Feature"},
	    glue = {"StepDef"},
	    plugin = {"pretty", "html:target/extentreports/Cucumber-Report.html","com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter:"}
	)
public class TestRunner extends AbstractTestNGCucumberTests {
	static {
		System.setProperty("extent.reporter.spark.start", "true");
		System.setProperty("extent.reporter.spark.out", "target/extentreports/extent-report.html");
		}
}


 