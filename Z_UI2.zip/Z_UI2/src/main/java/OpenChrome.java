import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;

public class OpenChrome {
    public static void main(String[] args) throws InterruptedException {
       
        System.setProperty("webdriver.edge.driver", "C:\\Users\\mynam.sujan\\eclipse-workspace\\UI\\msedgedriver_V_135.exe");

       
        WebDriver dr = new EdgeDriver();

        dr.manage().window().maximize();
        dr.get("https://www.amazon.in");
        dr.findElement(By.xpath("//div[@id=\"nav-xshop-container\"]/div[@id=\"nav-xshop\"]/ul[@class=\"nav-ul\"]/li[6]/div[@class=\"nav-div\"]")).click();
        WebElement element = dr.findElement(By.xpath("//div[@id=\"nav-progressive-subnav\"]/div[@id=\"nav-subnav\"]/a[2]/span[@class=\"nav-a-content\"]"));
        
        Actions action = new Actions(dr);
        action.moveToElement(element).perform();
        
        Thread.sleep(3000);
        
        dr.findElement(By.xpath("//*[@id=\"nav-flyout-aj:https://images-eu.ssl-images-amazon.com/images/G/31/img18/Electronics/Megamenu/megamenumar18f.json:subnav-sl-megamenu-1:0\"]/div[2]/div/div[2]/ul/li[3]/a")).click();
        JavascriptExecutor js = (JavascriptExecutor) dr;
        js.executeScript("window.scrollBy(0,1500)");
        Thread.sleep(5000);
        dr.findElement(By.xpath("/html/body/div[1]/div[1]/div[2]/div[3]/div/div/div/div[4]/div[9]/span/div/div/div[1]/span/a/div/img")).click();
        Thread.sleep(5000);
        String Mobile_Name = dr.findElement(By.xpath("//div[@id=\"titleSection\"]/h1/span")).getText();
        Mobile_Name = Mobile_Name.split("\\(")[0].trim();
        System.out.println("Name of the Mobile you have selected is: " + Mobile_Name);
        
        
        String priceText = dr.findElement(By.xpath("//div[@class=\"a-section a-spacing-none aok-align-center aok-relative\"]/span[3]")).getText();
        priceText = priceText.replace("₹", "").replace(",", "").trim();
        int Mobile_price = Integer.parseInt(priceText);
        System.out.println("Price of the Mobile you have selected is: ₹" + Mobile_price);
        
        
        String Specifications = dr.findElement(By.xpath("//div[@class=\"a-section a-spacing-small a-spacing-top-small\"]")).getText();
        System.out.println("Specifications of"+Mobile_Name+"are \n"+Specifications);
        
        
        List<WebElement> addToCartButton = dr.findElements(By.xpath("//*[@id=\"add-to-cart-button\"]"));
        List<WebElement> buyNowButton = dr.findElements(By.xpath("//*[@id=\"buy-now-button\"]"));

        if (addToCartButton.size() > 0) {
            System.out.println("Add to Cart button is Present !!");
        } else {
            System.out.println("Add to Cart button is NOT Present !!");
        }

        if (buyNowButton.size() > 0) {
            System.out.println("Buy Now button is Present !!");
        } else {
            System.out.println("Buy Now button is NOT Present !!");
        }
        
        
        dr.findElement(By.xpath("//*[@id=\"twotabsearchtextbox\"]")).sendKeys("Samsung Watches");
        dr.findElement(By.xpath("//div[@class=\"nav-right\"]/div[@class=\"nav-search-submit nav-sprite\"]/span")).click();

        js.executeScript("window.scrollBy(0,500)");
        
        
        
        dr.findElement(By.xpath("//div[@class=\"a-section aok-relative s-image-square-aspect\"]/img[@src=\"https://m.media-amazon.com/images/I/81i1Vn-KQuL._AC_UL320_.jpg\"]")).click();
        ArrayList<String> tabs = new ArrayList<String>(dr.getWindowHandles());
        dr.switchTo().window(tabs.get(1)); 
        Thread.sleep(5000);
        
        
        
        String text = dr.findElement(By.xpath("//div[@id=\"titleSection\"]/h1/span")).getText();
       
        if(text.contains("Samsung")) {
            System.out.println("Samsung is present");
        } else {
            System.out.println("Samsung is NOT present");
        }
        text=text.split("\\(")[0].trim();
        System.out.println("Name of the Watch is: "+text);
        js.executeScript("window.scrollBy(0,500)");
        

    }
}
