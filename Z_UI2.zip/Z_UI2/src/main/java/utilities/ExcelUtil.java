package utilities;
 
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map; 
public class ExcelUtil {

    private static Workbook workbook;
    private static Sheet sheet;
    private static Map<String, String> testData = new HashMap<>();
    public static void setExcelFile(String filePath, String sheetName) throws IOException {
        FileInputStream fis = new FileInputStream(filePath);
        workbook = new XSSFWorkbook(fis);
        sheet = workbook.getSheet(sheetName);
        loadTestData();
    }
	private static void loadTestData() {
		for (Row row : sheet) {
			Cell name = row.getCell(0);
			Cell data = row.getCell(1);
			if (name!= null && data != null) {
				String name1 = name.getStringCellValue();
				String data1 = data.getStringCellValue();
				testData.put(name1, data1); 
				}
			}
		}
	public static String getTestData(String elementName) {
		return testData.get(elementName);
	}
    public static String getCellData(int rowNum, int colNum) {
        Cell cell = sheet.getRow(rowNum).getCell(colNum);
        return cell.getStringCellValue();
    }
}
