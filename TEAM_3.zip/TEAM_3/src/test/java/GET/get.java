package GET;

//package Common_methods;
import org.apache.http.client.methods.CloseableHttpResponse;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;
 
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
 
import com.fasterxml.jackson.databind.ObjectMapper;
 
@SuppressWarnings("unused")
public class get {
    public void team_3(String apiUrl) {
//String apiUrl = "https://softwium.com/api/peoples";
 
        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            HttpGet request = new HttpGet(apiUrl);
            try (CloseableHttpResponse response = httpClient.execute(request)) {
                int statusCode = response.getStatusLine().getStatusCode();
                String responseBody = EntityUtils.toString(response.getEntity());
                JSONArray jsonResponse = new JSONArray(responseBody);
                Assert.assertEquals(statusCode, 200);
                System.out.println("Fetched Records:");
                for (int i = 0; i < jsonResponse.length(); i++) {
                    System.out.println(jsonResponse.getJSONObject(i).toString());
                }
                Assert.assertEquals(jsonResponse.getJSONObject(0).getInt("id"), 1);
            }
        } catch (Exception e) {
            e.printStackTrace();
Assert.fail("Failed to fetch records: " + e.getMessage());
        }
    }
     public void validate_1000_records(String apiURL) {
//String apiUrl = "https://softwium.com/api/peoples";
 
            try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
                HttpGet request = new HttpGet(apiURL);
                try (CloseableHttpResponse response = httpClient.execute(request)) {
                    int statusCode = response.getStatusLine().getStatusCode();
                    String responseBody = EntityUtils.toString(response.getEntity());
                    JSONArray jsonResponse = new JSONArray(responseBody);
 
                    Assert.assertEquals(statusCode, 200);
                    Assert.assertEquals(jsonResponse.length(), 1000);
 
                    for (int i = 0; i < jsonResponse.length(); i++) {
                        JSONObject obj = jsonResponse.getJSONObject(i);
                        Assert.assertTrue(obj.get("id") instanceof Integer);
                        Assert.assertTrue(obj.get("firstName") instanceof String);
                        Assert.assertTrue(obj.get("lastName") instanceof String);
                        Assert.assertTrue(obj.get("age") instanceof Integer);
                    }
 
                    System.out.println("Validated 1000 records with correct data types.");
                }
            } catch (Exception e) {
                e.printStackTrace();
Assert.fail("GET request validation failed: " + e.getMessage());
            }
        }
     
    
    
     }