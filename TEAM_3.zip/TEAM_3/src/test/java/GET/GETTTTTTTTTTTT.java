package GET;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
 
import java.io.File;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;
 
import com.fasterxml.jackson.databind.ObjectMapper;
 
 
@SuppressWarnings("unused")
public class GETTTTTTTTTTTT extends get{
  @Test(priority = 1)
  public void f1() throws InterruptedException {
team_3("https://softwium.com/api/peoples");
    Thread.sleep(5000);
  }
  @Test(priority = 2)
  public void f2() throws InterruptedException {
    Thread.sleep(5000);
validate_1000_records("https://softwium.com/api/peoples");
  }

  
  }