package POST;

import org.testng.annotations.Test;

public class POSTTTTTT extends PostRequest {
  @Test(priority = 1)
  public void f() {
	  sendData("https://softwium.com/api/peoples");
  }
}
