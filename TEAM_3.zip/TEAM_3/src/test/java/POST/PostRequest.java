package POST;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.entity.StringEntity;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.junit.Assert;

public class PostRequest {
    public void sendData(String apiUrl) {
        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            HttpPost postRequest = new HttpPost(apiUrl);
            postRequest.setHeader("Content-Type", "application/json");

            // Create JSON payload with the specified fields
            JSONObject jsonPayload = new JSONObject();
            jsonPayload.put("firstname", "John");
            jsonPayload.put("lastname", "Doe");
            jsonPayload.put("age", 30);

            // Set payload in request
            postRequest.setEntity(new StringEntity(jsonPayload.toString()));

            try (CloseableHttpResponse response = httpClient.execute(postRequest)) {
                int statusCode = response.getStatusLine().getStatusCode();
                String responseBody = EntityUtils.toString(response.getEntity());
                
                Assert.assertEquals(statusCode, 201); // Assuming success returns 201 Created
                
                System.out.println("Response from API:");
                System.out.println(responseBody);
            }
        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("Failed to send data: " + e.getMessage());
        }
    }
}