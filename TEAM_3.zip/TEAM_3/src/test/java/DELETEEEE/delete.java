package DELETEEEE;

import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;
 


public class delete {
    int statusCode;
    public int delete_by_id(String Url1) {
       
 
        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            HttpDelete request = new HttpDelete(Url1);
            CloseableHttpResponse response = httpClient.execute(request); 
                 statusCode = response.getStatusLine().getStatusCode();
                //System.out.println(statusCode);
                String responseBody = EntityUtils.toString(response.getEntity());
                //Assert.assertEquals(statusCode, 204);
                System.out.println("Deleted Record Response:");
                System.out.println(responseBody);
                //return statusCode;
            
        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("DELETE request failed: " + e.getMessage());
        }
		return statusCode;
    }
    public int getData(String apiUrl, int id) {
        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            HttpGet getRequest = new HttpGet(apiUrl + "/" + id);
            getRequest.setHeader("Accept", "application/json");

            CloseableHttpResponse response = httpClient.execute(getRequest); 
                statusCode = response.getStatusLine().getStatusCode();
                String responseBody = EntityUtils.toString(response.getEntity());

                //Assert.assertEquals(200, statusCode); 

                // Convert response string to JSON object
                JSONObject jsonResponse = new JSONObject(responseBody);

                System.out.println("Response from API:");
                System.out.println(jsonResponse.toString(4)); 
            
        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail("Failed to retrieve data: " + e.getMessage());
        }
        return statusCode;
    }
    
    
    
}
 
