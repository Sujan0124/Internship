package DELETEEEE;
 
import static org.testng.Assert.assertEquals;

import org.testng.annotations.Test;

import junit.framework.Assert;
 
public class DELETEEEE extends delete {
	@Test(priority = 1)
	  //Valid ID
	  public void delevevalid() throws InterruptedException {
	    
	int StatusCode	=  delete_by_id("https://softwium.com/api/peoples/1");

	Assert.assertEquals(204, StatusCode);

	  }
@Test(priority = 2)
public void deleteinvalid()  {
	int StatusCode	=  delete_by_id("https://softwium.com/api/peoples/1asd");

	Assert.assertEquals( 404,StatusCode);
}
@Test(priority = 3)
public void deleteinvalidURL()  {
	int StatusCode	=  delete_by_id("https://softwium.com/api/peoplessss/1");

	Assert.assertEquals(404, StatusCode);
}

@Test(priority = 4)
public void posted()  {
	
	int StatusCode	=  delete_by_id("https://softwium.com/api/peoples/1001");

	Assert.assertEquals(StatusCode, 204);

}

  @Test(priority = 5)
  public void get() {
	  int StatusCode = getData("https://softwium.com/api/peoples", 1001);
	  Assert.assertEquals(StatusCode, 200);
  }
}